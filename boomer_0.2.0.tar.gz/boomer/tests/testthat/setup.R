withr::local_options(boomer.ignore = op.boom$boomer.ignore, .local_envir = teardown_env())
