library(testthat)
library(boomer)

test_check("boomer")
